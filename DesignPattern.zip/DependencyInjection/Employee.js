"use strict";
exports.__esModule = true;
exports.Employee = void 0;
var EmployeeService_1 = require("./EmployeeService");
var Employee = /** @class */ (function () {
    function Employee() {
        this.employees = [];
        this.employeeService = new EmployeeService_1.EmployeeService();
    }
    Employee.prototype.displayEmployee = function () {
        this.employees = this.employeeService.getEmployees();
        console.table(this.employees);
    };
    return Employee;
}());
exports.Employee = Employee;
