import { IEmployee } from "./IEmployee";
import { EmployeeService } from "./EmployeeService";

export class Employee{
    private employees:IEmployee[]=[];
    private employeeService:EmployeeService;//new EmployeeService();

    constructor()
    {
        this.employeeService=new EmployeeService();
    }

    public displayEmployee():void
    {
        this.employees=this.employeeService.getEmployees();
        console.table(this.employees); 
    }
}