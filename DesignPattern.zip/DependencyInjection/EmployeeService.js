"use strict";
exports.__esModule = true;
exports.EmployeeService = void 0;
var EmployeeService = /** @class */ (function () {
    function EmployeeService() {
        this.employeeList = [
            {
                name: 'John',
                age: 25,
                desg: 'Manager'
            },
            {
                name: 'wilson',
                age: 45,
                desg: 'Sr.Manager'
            },
            {
                name: 'Laura',
                age: 28,
                desg: 'Tech Lead'
            }
        ];
    }
    EmployeeService.prototype.getEmployees = function () {
        return this.employeeList;
    };
    return EmployeeService;
}());
exports.EmployeeService = EmployeeService;
