import { IEmployee } from "./IEmployee";

export class EmployeeService
{
    private employeeList:IEmployee[]=[

        {
            name:'John',
            age:25,
            desg:'Manager'
        },
        {
            name:'wilson',
            age:45,
            desg:'Sr.Manager'
        },
        {
            name:'Laura',
            age:28,
            desg:'Tech Lead'
        }
    ];
    public getEmployees():IEmployee[]{
        return this.employeeList;
    }
}