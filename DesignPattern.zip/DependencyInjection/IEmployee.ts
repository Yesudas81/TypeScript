export interface IEmployee
{
    name:string,
    age:number,
    desg:string
}