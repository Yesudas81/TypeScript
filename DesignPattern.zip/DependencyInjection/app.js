"use strict";
exports.__esModule = true;
var Employee_1 = require("./Employee");
var employee = new Employee_1.Employee;
employee.displayEmployee();
