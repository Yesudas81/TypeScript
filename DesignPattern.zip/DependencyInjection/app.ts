import { Employee } from "./Employee";

let employee=new Employee;
employee.displayEmployee();