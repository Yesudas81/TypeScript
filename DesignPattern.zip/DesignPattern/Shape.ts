export interface Shape{
    draw():void;
}