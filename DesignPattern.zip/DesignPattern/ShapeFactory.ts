import { Circle } from "./Circle";
import { Rectangle } from "./Rectangle";
import { Shape } from "./Shape";
import { Square } from "./Square";

export class ShapeFactory
{
    public getShape(shapeType:string):Shape
    {
        switch(shapeType)
        {
            case 'CIRCLE': return new Circle();
            case 'SQUARE': return new Square();
            case 'RECTANGLE': return new Rectangle();
        }
    }
}