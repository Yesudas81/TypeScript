"use strict";
exports.__esModule = true;
var ShapeFactory_1 = require("./ShapeFactory");
var App = /** @class */ (function () {
    function App() {
    }
    App.main = function () {
        var shapeFactory = new ShapeFactory_1.ShapeFactory();
        var circle = shapeFactory.getShape('CIRCLE');
        circle.draw();
        var Square = shapeFactory.getShape('SQUARE');
        Square.draw();
        var rectangle = shapeFactory.getShape('RECTANGLE'); //new Rectangle();
        rectangle.draw();
    };
    return App;
}());
App.main();
