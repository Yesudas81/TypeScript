import { ShapeFactory } from "./ShapeFactory";

class App{
    public static main():void
    {
        let shapeFactory=new ShapeFactory();
       
        let circle=shapeFactory.getShape('CIRCLE');
        circle.draw();

        let Square=shapeFactory.getShape('SQUARE');
        Square.draw();

        let rectangle=shapeFactory.getShape('RECTANGLE');//new Rectangle();
        rectangle.draw();
        
    }
}

App.main();