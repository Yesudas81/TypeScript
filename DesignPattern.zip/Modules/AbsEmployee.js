"use strict";
exports.__esModule = true;
exports.AbsEmployee = void 0;
var AbsEmployee = /** @class */ (function () {
    function AbsEmployee(fName, lName, desg) {
        this.fName = fName;
        this.lName = lName;
        this.desg = desg;
    }
    return AbsEmployee;
}());
exports.AbsEmployee = AbsEmployee;
