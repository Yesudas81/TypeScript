import { IEmployee } from "./IEmployee";
export abstract class AbsEmployee implements IEmployee{
    fName:string;
    lName:string;
    desg:string;
    abstract bio():void;

    constructor(fName:string,lName:string,desg:string)
    {
        this.fName=fName;
        this.lName=lName;
        this.desg=desg;
    }
}