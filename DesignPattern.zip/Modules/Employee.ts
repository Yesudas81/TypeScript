import { AbsEmployee } from "./AbsEmployee";
export class Employee extends AbsEmployee
{
    constructor(fName:string,lName:string,desg:string)
    {
        super(fName,lName,desg);
    }
    
    bio(): void {
        console.log(`First Name: ${this.fName} Last Name: ${this.lName} Designation: ${this.desg}` );
    }
}