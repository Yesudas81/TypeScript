export interface IEmployee{
    fName:string,
    lName:string,
    desg:string,
    bio():void
}