import { Employee } from "./Employee";
let emp=new Employee("vivek","d","dev");
console.log(emp.fName);